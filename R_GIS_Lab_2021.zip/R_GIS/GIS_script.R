###############################################

# R lab - Working with GIS data
# Created for RST by Jack Cavanagh at J-PAL Global;
# Based on the tutorial by Nick Eubank found here: https://www.nickeubank.com/gis-in-r/
# Last Edited Oct 23rd, 2020

###############################################
#Set working directory and clean up work space:
setwd("/Users/johnccavanagh/Documents/R_RST/R_GIS")
rm(list = ls())

#Install packages: 
#install.packages(c("sp", "raster", "rgdal"))

#Activating packages
library (sp)
library (rgdal)
library (raster)

############### Part 1: Working with Vector data ####################
########### 1a: Creating and working with coordinates
toy.coordinates <- rbind(c(1.5, 2), c(2.5, 2), c(0.5, 0.5), c(1, 0.25), c(1.5,0), c(2, 0), c(2.5, 0), c(3, 0.25), c(3.5, 0.5))
toy.coordinates

##Turning those coordinates into a spatial object
my.first.points <- SpatialPoints(toy.coordinates)
plot(my.first.points)

#Exercise 1: Create another smiley face, but with a nose!


##Summarizing in two different ways
summary(my.first.points)
coordinates(my.first.points)


##In practice, most cases in which we are using GIS packages will involve real-world mapping. In order to do this,
### R needs a "reference system" -- a base layer of coordinates to project our coordinated ontio.
is.projected(my.first.points)  # see if a projection is defined. 
# Returns `NA` if no geographic coordinate system or projection; returns
# FALSE if has geographic coordinate system but no projection.

##Adding in a reference system and projecting the coordinates
crs.geo <- CRS("+init=EPSG:32633")  # UTM 33N
proj4string(my.first.points) <- crs.geo  # define projection system of our data
is.projected(my.first.points)
plot(my.first.points)

##Adding in attributes:
df <- data.frame(attr1 = c("a", "b", "z", "d", "e", "q", "w", "r", "z"), attr2 = c(101:109)) #creating DF of attributes
df
my.first.spdf <- SpatialPointsDataFrame(my.first.points, df) ## Creating spatial df out of points and attributes
summary(my.first.spdf)

## Can subset spdfs just like regular dfs
my.first.spdf[1:2, ]  # row 1 and 2 only
my.first.spdf[1:2, "attr1"]  # row 1 and 2 only, attr1
plot(my.first.spdf[which(my.first.spdf$attr2 > 105), ])  # select if attr2 > 5

############# 1b: Creating and working with polygons:
# create polyon objects from coordinates.  Each object is a single geometric
# polygon defined by a bounding line.
house1.building <- Polygon(rbind(c(1, 1), c(2, 1), c(2, 0), c(1, 0)))
house1.roof <- Polygon(rbind(c(1, 1), c(1.5, 2), c(2, 1)))
house2.building <- Polygon(rbind(c(3, 1), c(4, 1), c(4, 0), c(3, 0)))
house2.roof <- Polygon(rbind(c(3, 1), c(3.5, 2), c(4, 1)))
house2.door <- Polygon(rbind(c(3.25, 0.75), c(3.75, 0.75), c(3.75, 0), c(3.25,0)), hole = TRUE)

# create lists of polygon objects from polygon objects and unique ID A
# `Polygons` is like a single observation.
h1 <- Polygons(list(house1.building, house1.roof), "house1")
h2 <- Polygons(list(house2.building, house2.roof, house2.door), "house2")

# create spatial polygons object from lists A SpatialPolygons is like a
# shapefile or layer.
houses <- SpatialPolygons(list(h1, h2))
plot(houses)

## We can add attributes to polygons as well
attr <- data.frame(attr1 = 1:2, attr2 = 6:5, row.names = c("house2", "house1"))
houses.DF <- SpatialPolygonsDataFrame(houses, attr)
as.data.frame(houses.DF)  # Notice the rows were re-ordered!

## Plotting the new spatial dataframe
spplot(houses.DF)

## We can project polygons as well
crs.geo <- CRS("+init=EPSG:4326")  # geographical, datum WGS84
proj4string(houses.DF) <- crs.geo  # define projection system of our data

## Exercise 1: Creating Lesotho
sa.outline <- rbind(c(16, -29), c(33, -21), c(33, -29), c(26, -34), c(17, -35))
sa.hole <- rbind(c(29, -28), c(27, -30), c(28, -31))
lesotho <- rbind(c(29, -28), c(27, -30), c(28, -31))

# Make Polygon objects
sa.outline.poly <- Polygon(sa.outline)
sa.hole.poly <- Polygon(sa.hole, hole = TRUE)
lesotho.poly <- Polygon(lesotho)

# Make Polygons objects
sa.polys <- Polygons(list(sa.outline.poly, sa.hole.poly), "SA")
lesotho.polys <- Polygons(list(lesotho.poly), "Lesotho")

# Make spatialy Polygons
map <- SpatialPolygons(list(sa.polys, lesotho.polys))

# Check
plot(map)
# Add data
df <- data.frame(c(7000, 1000), row.names = c("SA", "Lesotho"))
mapDF <- SpatialPolygonsDataFrame(map, df)

# Add WGS 84 coordinate system
proj4string(mapDF) <- CRS("+init=EPSG:4326")

# Plot
spplot(mapDF)

###### Part 1c: Working with actual vector data
rm(list = ls())
##Reading in the shapefiles -- GIS data generally comes in "packs" of multiple files; readOGR is good at dealing with this
sf <- readOGR(dsn = "RGIS1_Data/shapefiles",layer = "sf_incomes")

##Looking at the data
class(sf)
summary(sf)
names(sf)
head(as.data.frame(sf))

##Simple plots
spplot(sf, "MdIncHH")
spplot(sf, c("MdIncPC", "MdIncHH"))

## Exercise 2: plot only areas where med. HH income >= $40,000:


############ Part 2: Working with Raster data ################
rm(list = ls())

##Creating a basic raster object
basic_raster <- raster(ncol = 5, nrow = 10, xmn = 0, xmx = 5, ymn = 0, ymx = 10)
basic_raster

##Have to populate the values
hasValues(basic_raster)

##Now we have a proper raster object
values(basic_raster) <- 1:50  # Note 50 is the total number of cells in the grid. 
plot(basic_raster)
big_basic_raster <- basic_raster*2
plot(big_basic_raster)

##We want to project raster objects too
projection(basic_raster) <- "+init=EPSG:4326"

##Loading Raster data
raster_from_file <- raster("RGIS1_Data/sanfrancisconorth.dem")
##Plotting raster data
plot(raster_from_file)

##You can subset raster data, too:
r_big <- raster_from_file
r_big[r_big<150] <-0
plot(r_big)

##Use the "cellStats" command to gather summary statistics from raster values 
mean_alt <- cellStats(raster_from_file, "mean")

#Exercise 3: Just plot the points above the mean altidue for the raster object

