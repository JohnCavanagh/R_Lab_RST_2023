rm(list = ls()) ##Clean up workspace
setwd("/Users/johnccavanagh/Documents/R_GIS_2022")
## Workflow packages
library(googlesheets4) ##For connecting to google sheets
library(googledrive) ##For connecting to google drive

### Data cleaning packages
library(dplyr)
library(reshape2)
library(scales)
library(tidyr)
library(lubridate) ## For dates
library(taRifx) ## For destring

### Plotting packages
library(ggplot2)
library(RColorBrewer)

### GIS packages
library(sp)
library(rgdal)
library(rgeos)
library(classInt)
library (raster)

################ GIS ###############
############### Part 1: Working with Vector data ####################
########### 1a: Creating and working with coordinates
toy.coordinates <- rbind(c(1.5, 2), c(2.5, 2), c(0.5, 0.5), c(1, 0.25), c(1.5,0), c(2, 0), c(2.5, 0), c(3, 0.25), c(3.5, 0.5))
toy.coordinates

##Turning those coordinates into a spatial object
my.first.points <- SpatialPoints(toy.coordinates)
plot(my.first.points)

##Summarizing in two different ways
summary(my.first.points)
coordinates(my.first.points)

##In practice, most cases in which we are using GIS packages will involve real-world mapping. In order to do this,
### R needs a "reference system" -- a base layer of coordinates to project our coordinated ontio.
is.projected(my.first.points)  # see if a projection is defined. 
# Returns `NA` if no geographic coordinate system or projection; returns
# FALSE if has geographic coordinate system but no projection.

##Adding in a reference system and projecting the coordinates
crs.geo <- CRS("+init=EPSG:32633")  # UTM 33N
proj4string(my.first.points) <- crs.geo  # define projection system of our data
is.projected(my.first.points)
plot(my.first.points)

##Adding in attributes:
df <- data.frame(attr1 = c("a", "b", "z", "d", "e", "q", "w", "r", "z"), attr2 = c(101:109)) #creating DF of attributes
df
my.first.spdf <- SpatialPointsDataFrame(my.first.points, df) ## Creating spatial df out of points and attributes
summary(my.first.spdf)

## Can subset spdfs just like regular dfs
my.first.spdf[1:2, ]  # row 1 and 2 only
my.first.spdf[1:2, "attr1"]  # row 1 and 2 only, attr1
plot(my.first.spdf[which(my.first.spdf$attr2 > 105), ])  # select if attr2 > 5


######## Working with actual shapefile data ###########
### Reading in our data from google sheets
puller_url <- "https://docs.google.com/spreadsheets/d/19TL60uQSs2-68b8ibOmoyHU05IGFYCO0h92nGUXz_c8/edit#gid=294824737"
b_2010 <- read_sheet(puller_url, sheet = "2010")
b_2014 <- read_sheet(puller_url, sheet = "2014")

### Reading in maps of Ecuador
Ecua <- readOGR(dsn = "ecu_adm_inec_20190724_shp",layer = "ecu_admbnda_adm3_inec_20190724")
Prov <- readOGR(dsn ="ecu_adm_inec_20190724_shp", layer = "ecu_admbnda_adm1_inec_20190724")

df <- as.data.frame(Ecua) ##Can check the features of the polygon by turning them into a dataframe

### Preparing to merge
Ecua$CODIGO <- gsub("EC", "", Ecua$ADM3_PCODE)
for (i in 1:length(Ecua$CODIGO)){
  if (substr(Ecua$CODIGO[i],1,1) =="0"){
    Ecua$CODIGO[i] = substr(Ecua$CODIGO[i], start = 2, stop = 6)
  }
}
Ecua$CODIGO <- destring(Ecua$CODIGO)

Ecuador <- merge(Ecua, b_2014, by.x="CODIGO", by.y = "CODIGO")
Ecuador10 <- merge(Ecua, b_2010, by.x="CODIGO", by.y = "CODIGO", all.x = TRUE, all.y = TRUE)

scale.parameter = 0.35  # scaling paramter. less than 1 is zooming in, more than 1 zooming out. 
xshift = 5.5  # Shift to right in map units. 
original.bbox = Ecuador@bbox  # Pass bbox of your Spatial* Object. 

edges <- original.bbox

edges[1, ] <- (edges[1, ] - mean(edges[1, ])) * scale.parameter + mean(edges[1,]) + xshift
my_colors <- c("antiquewhite1","lightgoldenrod1","peru","coral3","coral4")
my_colors_switch <- c("coral4","coral3", "peru", "lightgoldenrod1", "antiquewhite1")

prov_layer <- list("sp.lines", Prov, col = "brown4",lwd=2, first = FALSE)

breaks.qt <- classIntervals(Ecuador$mean_weight, n = 5, style = "quantile", intervalClosure = "right")
x <- spplot(Ecuador, "mean_weight" ,col.regions = my_colors_switch, sp.layout=prov_layer, at = breaks.qt$brks, col = "gray51",lwd = .05,xlim = edges[1, ], par.settings = list(axis.line = list(col = 'transparent')),main=list(label="Mean birth weight by parroquia, 2013-2015"))
png(filename = "weight_map_2013-2015.png")
print(x)
dev.off()

Ecuador10$mean_weight <- as.numeric(Ecuador10$mean_weight)
x10 <- spplot(Ecuador10, "mean_weight" ,col.regions = my_colors_switch,sp.layout=prov_layer, at = breaks.qt$brks, col = "gray51",lwd = .05, xlim = edges[1, ], par.settings = list(axis.line = list(col = 'transparent')), main=list(label="Mean birth weight by parroquia, 2006-2010"))
png(filename = "weight_map_2006-2010.png")
print(x10)
dev.off()

############ Part 2: Working with Raster data ################
rm(list = ls())

##Creating a basic raster object
basic_raster <- raster(ncol = 5, nrow = 10, xmn = 0, xmx = 5, ymn = 0, ymx = 10)
basic_raster

##Have to populate the values
hasValues(basic_raster)

##Now we have a proper raster object
values(basic_raster) <- 1:50  # Note 50 is the total number of cells in the grid. 
plot(basic_raster)
big_basic_raster <- basic_raster*2
plot(big_basic_raster)

##We want to project raster objects too
projection(basic_raster) <- "+init=EPSG:4326"

##Loading Raster data
raster_from_file <- raster("RGIS1_Data/sanfrancisconorth.dem")
##Plotting raster data
plot(raster_from_file)

##You can subset raster data, too:
r_big <- raster_from_file
r_big[r_big<150] <-0
plot(r_big)

##Use the "cellStats" command to gather summary statistics from raster values 
mean_alt <- cellStats(raster_from_file, "mean")

